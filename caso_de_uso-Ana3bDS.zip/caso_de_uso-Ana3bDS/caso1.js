//importações
const express = require("express")
const jwt = require("jsonwebtoken")
const bcrypt = require("bcrypt")

const app = express() //interpreta o corpo da requisição
app.use(express.json()) //intancia a app express

const SECRET = 'beijamimégaykkkkkkkkkkkk'
const users = []; //BD em memória

//cadastro do cliente
app.post("/cadastroCliente", async(req, res)=>{
    const {email, senha} = req.body;
    const senhaCriptografada = await bcrypt.hash(senha, 8)
    res.status(201).send("Usuario cadastrado com sucesso")
})

//login

app.post("/login", async(req, res)=>{
    const {email, senha} = req.body;
    const Usuario = users.find(u => u.email)
    if(!Usuario || !(await bcrypt.compare(senha, Usuario.senha))){
        return res.status(401).send("Usuario não esiste")
    }

    const token = jwt.sign({email}, SECRET, {expiresIn: '1h'});
    res.json({token})
})

function autenticarToken(req, res, next){
    const authHeader = req.headers['authorization']
    const token = authHeader?.split(' ')[1];
    if(!token) return res.sendStatus(401);

    jwt.verify(token, SECRET, (err, Usuario)=>{
        if(err) return res.sendStatus(401)
        req.Usuario = Usuario
        next();
    })
}

/*
DESAFIO:
ROTA GET - CRIAR A ROTA GET
onde ela deve retornar uma mensagem de:
Bem vindo ao painel, usuario: email@gmail.com
*/
app.get()

app.listen(3000, () => console.log("API rodano na porta 3000"))